Стартовий проект React
Файли:
App.jsx, index.jsx